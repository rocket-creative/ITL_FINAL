/**
 * Frequently Asked Questions Section - displays MASTER TEXT exactly
 * Source: homepage.md lines 80-86
 * @version 3.0.0 - Using Intersection Observer for scroll animations
 */

'use client';

import { useState } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

interface FAQ {
  question: string;
  answer: string;
}

interface FAQData {
  title: string;
  faqs: FAQ[];
}

export default function FAQSection({ data }: { data: FAQData }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  
  // Create refs for FAQ items
  const faqRefs = data.faqs.map(() => useScrollAnimation<HTMLDivElement>(0.1));

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section
      className="flex flex-col justify-start items-center"
      style={{ backgroundColor: 'white', padding: '50px 20px' }}
    >
      {/* Section Title - MASTER TEXT */}
      <h2
        style={{
          color: '#2384da',
          textAlign: 'center',
          letterSpacing: '-.5px',
          fontFamily: 'Poppins, sans-serif',
          fontSize: '2rem',
          fontWeight: 700,
          lineHeight: 1,
          marginBottom: '30px',
        }}
      >
        {data.title}
      </h2>

      {/* FAQ Items */}
      <div style={{ maxWidth: '800px', width: '100%' }}>
        {data.faqs.map((faq, index) => (
          <div
            key={index}
            ref={faqRefs[index]}
            className={`animate-initial animate-fade-in-up animate-delay-${Math.min(100 + index * 100, 800)}`}
            style={{
              backgroundColor: '#f7f7f7',
              marginBottom: '10px',
              border: '.5px solid #e0e0e0',
              overflow: 'hidden',
            }}
          >
            {/* Question - MASTER TEXT */}
            <button
              onClick={() => toggleFAQ(index)}
              className="w-full text-left flex justify-between items-center transition-colors duration-300 hover:bg-gray-100"
              style={{ padding: '20px', cursor: 'pointer' }}
            >
              <span
                style={{
                  color: '#333',
                  fontFamily: 'Poppins, sans-serif',
                  fontSize: '1rem',
                  fontWeight: 500,
                }}
              >
                {faq.question}
              </span>
              <span
                className="transition-transform duration-300"
                style={{
                  transform: openIndex === index ? 'rotate(180deg)' : 'rotate(0deg)',
                  color: 'teal',
                  fontSize: '1.2rem',
                }}
              >
                ▼
              </span>
            </button>

            {/* Answer - MASTER TEXT */}
            <div
              className="transition-all duration-300 overflow-hidden"
              style={{
                maxHeight: openIndex === index ? '500px' : '0',
                opacity: openIndex === index ? 1 : 0,
              }}
            >
              <p
                style={{
                  padding: '0 20px 20px',
                  color: '#666',
                  fontFamily: 'var(--system-ui)',
                  fontSize: '.9rem',
                  fontWeight: 400,
                  lineHeight: '1.4rem',
                }}
              >
                {faq.answer}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
